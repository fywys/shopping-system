package com.bjsxt.shopping.category;

public class GradeOutOfBoundsException extends RuntimeException {

}
